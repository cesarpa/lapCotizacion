package com.lap.lapcotizacion;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LapCotizacionApplicationTests {

	@Test
	void contextLoads() {
	}

}
